# -*- coding: utf-8 -*-

"""
    raas_v2.http.http_context

    This file was automatically generated for Tango Card, Inc. by APIMATIC v2.0 ( https://apimatic.io ).
"""

class HttpContext(object):

    """An HTTP Context that contains both the original HttpRequest
    object that intitiated the call and the HttpResponse object that
    is the result of the call.

    Attributes:
        request (HttpRequest): The original request object.
        response (HttpResponse): The returned response object after
            executing the request. Note that this may be None
            depending on if and when an error occurred.

    """

    def __init__(self,
                 request,
                 response):
        """Constructor for the HttpContext class

        Args:
            request (HttpRequest): The HTTP Request.
            response (HttpResponse): The HTTP Response.

        """
        self.request = request
        self.response = response
